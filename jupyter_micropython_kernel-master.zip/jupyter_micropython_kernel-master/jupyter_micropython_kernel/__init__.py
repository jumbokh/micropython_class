"""Jupyter kernel to interact with a MicroPython ESP8266 or ESP32 over its serial REPL."""

__version__ = '0.1.3.2'

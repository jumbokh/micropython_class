# config.py
SSID = "jumboap"        # WiFi名稱
PASSWORD = "0953313123"    # WiFi密碼
KEY="773d7b963fd37c801edf31fb9a7394fd" #openweathermap
APIKEY = "cBVp_iFaovrfRFXjy8P4rn" # iFTTT Key
# config.py
SSID = "<WiFi名稱>"        # WiFi名稱
PASSWORD = "<WiFi密碼>"    # WiFi密碼
APIKEY = "<IFTTT API KEY>"    # IFTTT Api key
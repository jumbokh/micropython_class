from machine import Pinimport timep2 = Pin(15, Pin.OUT)
p2.value(1)time.sleep(1)

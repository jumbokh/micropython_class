# -*- coding: utf-8 -*-

"""
   程式說明請參閱18-29頁
"""

import time
import ntptime
t = ntptime.time()
time.localtime(t)
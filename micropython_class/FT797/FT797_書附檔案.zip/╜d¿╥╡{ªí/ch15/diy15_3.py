# -*- coding: utf-8 -*-

"""
   程式說明請參閱15-16頁
"""

for y in range(3):
    for x in range(5):
        print('*', end='')
    print('\n')
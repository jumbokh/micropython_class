# -*- coding: utf-8 -*-

"""
   程式說明請參閱10-11頁
"""

from servo import Servo
s1 = Servo(0)
s1.rotate(120)
s1.rotate(60)
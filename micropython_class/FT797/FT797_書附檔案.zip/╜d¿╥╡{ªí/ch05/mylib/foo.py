pin = const(2)

def greet(user):
    print('hello, ' + user)

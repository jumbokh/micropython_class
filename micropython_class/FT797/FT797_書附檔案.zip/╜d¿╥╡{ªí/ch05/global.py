# -*- coding: utf-8 -*-

"""
   程式說明請參閱5-8頁
"""

total = 10

def count():
    global total
    total += 1
    print(total)

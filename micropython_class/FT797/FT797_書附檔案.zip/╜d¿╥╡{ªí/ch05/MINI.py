# -*- coding: utf-8 -*-

"""
   程式說明請參閱5-10頁
"""

D0 = const(16)
D1 = const(5)
D2 = const(4)
D3 = const(0)
D4 = const(2)
D5 = const(14)
D6 = const(12)
D7 = const(13)
D8 = const(15)
TX = const(1)
RX = const(3)

def hello():
   print("hello")

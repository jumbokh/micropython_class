stm32flash 0.5

This binary is for Microsoft Windows 64-bit

It was built using MinGW-64 from MSYS2 with gcc 5.3.0,
for build instructions please see:
https://sourceforge.net/p/stm32flash/wiki/Build/

Source code:
https://sourceforge.net/p/stm32flash/code/ci/v0.5/tree/

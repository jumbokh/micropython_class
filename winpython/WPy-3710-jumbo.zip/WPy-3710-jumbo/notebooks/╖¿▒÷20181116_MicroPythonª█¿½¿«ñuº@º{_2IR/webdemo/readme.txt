ampy --port=com13 put ap.txt

ampy --port=com13 put main.py

ampy --port=com13 put webtool.html


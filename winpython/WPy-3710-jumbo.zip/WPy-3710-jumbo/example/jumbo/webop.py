import bs4
from bs4 import BeautifulSoup

mainSoup = BeautifulSoup("""
<html>
   <div class='first'></div>
   <div class='second'></div>
</html>
""", 'html.parser')

extraSoup = BeautifulSoup('<span class="first-content"></span>', 'html.parser')
tag = mainSoup.find(class_='first')
tag.insert(1, extraSoup.span)

print mainSoup.find(class_='second')
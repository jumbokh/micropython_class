# config.py
SSID = "<your SSID>"        # WiFi名稱
PASSWORD = "<your password>"    # WiFi密碼
import upip
# http://yhhuang1966.blogspot.com/2019/07/micropython-on-esp32-upip-picoweb-2.html
upip.install('picoweb')
upip.install('micropython-uasyncio')
upip.install('micropython-pkg_resources')
upip.install('utemplate')
upip.install('pycopy-ulogging') 